// This gets injected into the webpage itself

alert("foreground script");
console.log("foreground script");